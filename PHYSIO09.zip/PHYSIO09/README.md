# PHYSIO09

## Frontend
A clean appointment dashboard for physiotherapy sessions. Deployed via Vercel.

## Backend
Flask API that sends SMS reminders using Twilio. Deployable on Railway.

### Environment Variables

| Variable | Description |
|----------|-------------|
| `TWILIO_SID` | Twilio Account SID |
| `TWILIO_AUTH_TOKEN` | Twilio Auth Token |
| `TWILIO_PHONE` | Twilio phone number (E.164 format) |

Deploy using:

```
pip install -r requirements.txt
gunicorn app:app
```
