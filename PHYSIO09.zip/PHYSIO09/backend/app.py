from flask import Flask, request
from datetime import datetime, timedelta
from twilio.rest import Client
import os

app = Flask(__name__)

appointments = [
    {
        "name": "John Doe",
        "phone": "+15551234567",
        "date": (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d"),
        "time": "10:00 AM"
    },
    {
        "name": "Jane Smith",
        "phone": "+15557654321",
        "date": (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d"),
        "time": "2:30 PM"
    }
]

@app.route("/")
def index():
    return "Physio Reminder API Running"

@app.route("/send-reminders", methods=["POST"])
def send_reminders():
    account_sid = os.getenv("TWILIO_SID")
    auth_token = os.getenv("TWILIO_AUTH_TOKEN")
    twilio_phone = os.getenv("TWILIO_PHONE")
    client = Client(account_sid, auth_token)

    tomorrow = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
    filtered = [appt for appt in appointments if appt["date"] == tomorrow]

    for appt in filtered:
        message = f"Hi {appt['name']}, reminder for your physiotherapy appointment tomorrow at {appt['time']}."
        client.messages.create(
            body=message,
            from_=twilio_phone,
            to=appt["phone"]
        )
    return "Reminders sent successfully!"
