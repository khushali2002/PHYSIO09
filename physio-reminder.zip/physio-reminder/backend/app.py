from flask import Flask, request
from datetime import datetime, timedelta
from twilio.rest import Client
import os

app = Flask(__name__)

appointments = [
    {
        "name": "John Doe",
        "phone": "+15551234567",
        "date": (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d"),
        "time": "10:00 AM"
    },
    {
        "name": "Jane Smith",
        "phone": "+15557654321",
        "date": (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d"),
        "time": "2:30 PM"
    }
]

@app.route('/send-reminders', methods=['POST'])
def send_reminders():
    account_sid = os.getenv('TWILIO_SID')
    auth_token = os.getenv('TWILIO_AUTH_TOKEN')
    twilio_phone = os.getenv('TWILIO_PHONE')
    client = Client(account_sid, auth_token)

    tomorrow = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d")
    filtered = [appt for appt in appointments if appt["date"] == tomorrow]

    for appt in filtered:
        message_body = (
            f"Hello {appt['name']}, this is a reminder for your physiotherapy "
            f"appointment tomorrow at {appt['time']}. See you soon!"
        )
        client.messages.create(
            body=message_body,
            from_=twilio_phone,
            to=appt['phone']
        )

    return "Reminders sent!"
